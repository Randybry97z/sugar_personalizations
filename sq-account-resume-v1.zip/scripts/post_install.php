<?php
function post_install() {
/*
echo "UPGRADE DATABASE"."<br>";

$sql ="INSERT INTO fields_meta_data (id, name, vname, comments, custom_module, type, len, required, deleted, audited, massupdate, duplicate_merge, reportable, importable) VALUES ('Emailsaddress_email_c', 'address_email_c', 'LBL_ADDRESS_EMAIL_C', 'Example Varchar Vardef', 'Emails', 'varchar', 255, 0, 0, 0, 0, 0, 1, 'true')";
$result=$GLOBALS['db']->query($sql);
echo $sql."<br>";
echo print_r($result,true)."<br>";

$sql ="CREATE TABLE IF NOT EXISTS emails_cstm (id_c char(36)  NOT NULL  , PRIMARY KEY (id_c)) CHARACTER SET utf8 COLLATE utf8_general_ci";
$result=$GLOBALS['db']->query($sql)
echo $sql."<br>";
echo print_r($result,true)."<br>";

$sql ="ALTER TABLE emails_cstm ADD COLUMN address_email_c varchar(255)  NULL";
$result=$GLOBALS['db']->query($sql);
echo $sql."<br>";
echo print_r($result,true)."<br>";

$sql ="ALTER TABLE emails_cstm ADD INDEX(address_email_c)";
$result=$GLOBALS['db']->query($sql);
echo $sql."<br>";
echo print_r($result,true)."<br>";


$sql ="INSERT INTO emails_cstm (id_c,address_email_c) SELECT e.email_id,ea.email_address FROM emails_email_addr_rel e INNER JOIN email_addresses ea ON e.email_address_id = ea.id AND e.deleted=0 AND ea.deleted=0 WHERE e.address_type = 'to' group by e.email_id ORDER BY 1";
$result=$GLOBALS['db']->query($sql);
echo $sql."<br>";
echo print_r($result,true)."<br>";

$sql ="DELETE FROM emails_cstm WHERE id_c NOT IN (SELECT id FROM emails)";
$result=$GLOBALS['db']->query($sql);
echo $sql."<br>";
echo print_r($result,true)."<br>";


*/
}
?>